# Claude Sonnet 5.5 - Independent Merkle Code Audit
Report prepared 2026-10-14; original Python source obtained from user-supplied files.

## Replay
Requires Python 3.10+; tested in Python 3.13.5, not rerun in Claude's reported 3.12.
No network or third-party Python dependencies.

  python -S -m unittest -v test_merkle
  python -S replay_claude_merkle_audit.py > current_results.json

The original test filename was `test merkle.py`. This ZIP uses byte-identical
`test_merkle.py` so standard unittest import works; SHA-256 is unchanged.

## Key caveats
- Verification is empirical and limited, not security certification.
- Shared-thread append is explicitly outside Claude's post-challenge scope.
- Some intentional malformed container cases raise despite an explicit public
  verifier promise to return False for all malformed inputs.
- The supplied Claude screenshots are incomplete; rubric scores are
  observations limited to the visible exchange.
- `core.py` and `verify.py` concern a different project and are excluded.

References: RFC 6962 and RFC 9162 at https://www.rfc-editor.org/
