"""
Test suite for merkle.py. Standard library only; run with:

    python -m unittest -v test_merkle

Strategy: the module's generators are recursive and its verifiers are iterative,
and the reference below re-implements RFC 6962 hashing from scratch with
hashlib, sharing no code with the module. Agreement across all three is the
evidence of correctness; the published vectors anchor it to the RFC.
"""

import hashlib
import random
import unittest

from merkle import (
    MerkleTree,
    hash_children,
    hash_empty,
    hash_leaf,
    verify_consistency,
    verify_inclusion,
)


# ---------------------------------------------------------------- reference

def _sha(b):
    return hashlib.sha256(b).digest()


def ref_mth(leaves):
    """RFC 6962 section 2.1, written directly from the definition."""
    n = len(leaves)
    if n == 0:
        return _sha(b"")
    if n == 1:
        return _sha(b"\x00" + leaves[0])
    k = 1
    while k * 2 < n:
        k *= 2
    return _sha(b"\x01" + ref_mth(leaves[:k]) + ref_mth(leaves[k:]))


def make_leaves(n, tag=b"leaf-"):
    return [tag + str(i).encode() for i in range(n)]


def flip(h, bit=0):
    b = bytearray(h)
    b[0] ^= 1 << bit
    return bytes(b)


# --------------------------------------------------------------------- tests

class KnownVectors(unittest.TestCase):
    # Certificate Transparency reference tree (RFC 6962 test data).
    LEAVES = [bytes.fromhex(h) for h in (
        "", "00", "10", "2021", "3031", "40414243",
        "5051525354555657", "606162636465666768696a6b6c6d6e6f",
    )]
    ROOTS = [
        "6e340b9cffb37a989ca544e6bb780a2c78901d3fb33738768511a30617afa01d",
        "fac54203e7cc696cf0dfcb42c92a1d9dbaf70ad9e621f4bd8d98662f00e3c125",
        "aeb6bcfe274b70a14fb067a5e5578264db0fa9b51af5e0ba159158f329e06e77",
        "d37ee418976dd95753c1c73862b9398fa2a2cf9b4ff0fdfe8b30cd95209614b7",
        "4e3bbb1f7b478dcfe71fb631631519a3bca12c9aefca1612bfce4c13a86264d4",
        "76e67dadbcdf1e10e1b74ddc608abd2f98dfb16fbce75277b5232a127f2087ef",
        "ddb89be403809e325750d3d263cd78929c2942b7942a34b77e122c9594a74c8c",
        "5dc9da79a70659a9ad559cb701ded9a2ab9d823aad2f4960cfe370eff4604328",
    ]

    def test_empty_root(self):
        self.assertEqual(
            hash_empty().hex(),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        )
        self.assertEqual(MerkleTree().root(), hash_empty())

    def test_ct_roots_every_prefix(self):
        tree = MerkleTree()
        for i, leaf in enumerate(self.LEAVES):
            tree.append(leaf)
            self.assertEqual(tree.root().hex(), self.ROOTS[i], f"size {i + 1}")
        for i, expected in enumerate(self.ROOTS):  # historical roots after full build
            self.assertEqual(tree.root(i + 1).hex(), expected)


class AgainstReference(unittest.TestCase):
    def test_root_matches_reference_for_every_size(self):
        leaves = make_leaves(130)
        tree = MerkleTree()
        for i, leaf in enumerate(leaves, start=1):
            tree.append(leaf)
            self.assertEqual(tree.root(), ref_mth(leaves[:i]), f"size {i}")

    def test_historical_roots_are_stable_under_growth(self):
        leaves = make_leaves(100)
        tree = MerkleTree(leaves[:40])
        frozen = {s: tree.root(s) for s in range(0, 41)}
        for leaf in leaves[40:]:
            tree.append(leaf)
        for s, h in frozen.items():
            self.assertEqual(tree.root(s), h)
            self.assertEqual(h, ref_mth(leaves[:s]))


class InclusionProofs(unittest.TestCase):
    def test_exhaustive_valid(self):
        for n in range(1, 71):
            leaves = make_leaves(n)
            tree = MerkleTree(leaves)
            root = ref_mth(leaves)  # verify against the independent root
            for m in range(n):
                proof = tree.inclusion_proof(m)
                self.assertTrue(verify_inclusion(leaves[m], m, n, proof, root), (n, m))

    def test_historical_size_proofs(self):
        leaves = make_leaves(50)
        tree = MerkleTree(leaves)
        for size in range(1, 51):
            root = ref_mth(leaves[:size])
            for m in range(size):
                proof = tree.inclusion_proof(m, size)
                self.assertTrue(verify_inclusion(leaves[m], m, size, proof, root))

    def test_proof_length_is_logarithmic(self):
        tree = MerkleTree(make_leaves(1000))
        for m in (0, 1, 499, 998, 999):
            self.assertLessEqual(len(tree.inclusion_proof(m)), 10)  # ceil(log2 1000)

    def test_exhaustive_rejection(self):
        for n in range(1, 41):
            leaves = make_leaves(n)
            tree = MerkleTree(leaves)
            root = tree.root()
            for m in range(n):
                proof = tree.inclusion_proof(m)
                # wrong leaf data
                self.assertFalse(verify_inclusion(b"forged", m, n, proof, root))
                # wrong root
                self.assertFalse(verify_inclusion(leaves[m], m, n, proof, flip(root)))
                # wrong index (every other index)
                for m2 in range(n):
                    if m2 != m:
                        self.assertFalse(verify_inclusion(leaves[m], m2, n, proof, root), (n, m, m2))
                # wrong tree size, paired with that size's honest root
                extended = make_leaves(n + 2)
                for n2 in (n - 1, n + 1, n + 2):
                    honest = ref_mth(extended[:n2])
                    self.assertFalse(verify_inclusion(leaves[m], m, n2, proof, honest), (n, m, n2))
                # any single flipped bit in any proof element
                for j in range(len(proof)):
                    bad = list(proof)
                    bad[j] = flip(bad[j], bit=j % 8)
                    self.assertFalse(verify_inclusion(leaves[m], m, n, bad, root))
                # truncated / extended / reordered
                if proof:
                    self.assertFalse(verify_inclusion(leaves[m], m, n, proof[:-1], root))
                    self.assertFalse(verify_inclusion(leaves[m], m, n, proof[1:], root))
                self.assertFalse(verify_inclusion(leaves[m], m, n, proof + [root], root))
                if len(proof) >= 2 and proof[0] != proof[1]:
                    swapped = [proof[1], proof[0]] + proof[2:]
                    self.assertFalse(verify_inclusion(leaves[m], m, n, swapped, root))

    def test_single_leaf_tree(self):
        tree = MerkleTree([b"only"])
        self.assertEqual(tree.inclusion_proof(0), [])
        self.assertEqual(tree.root(), hash_leaf(b"only"))
        self.assertTrue(verify_inclusion(b"only", 0, 1, [], tree.root()))
        self.assertFalse(verify_inclusion(b"only", 0, 1, [tree.root()], tree.root()))


class SizeBinding(unittest.TestCase):
    """
    Documented property, not a bug: a verifier is told (size, root) together and
    must obtain that pair from a trusted source (e.g. a signed tree head). The
    proof's shape does not authenticate the size on its own: index 0 in a tree
    of 3 and in a tree of 4 have identical path shapes, so the 3-leaf root
    verifies if the caller *claims* size 4. An honest size-4 root never does.
    """

    def test_size_is_authenticated_only_through_the_root(self):
        leaves = make_leaves(4)
        t3, t4 = MerkleTree(leaves[:3]), MerkleTree(leaves)
        proof = t3.inclusion_proof(0)
        self.assertTrue(verify_inclusion(leaves[0], 0, 3, proof, t3.root()))
        self.assertTrue(verify_inclusion(leaves[0], 0, 4, proof, t3.root()))   # shape coincidence
        self.assertFalse(verify_inclusion(leaves[0], 0, 4, proof, t4.root()))  # honest root rejects


class ConsistencyProofs(unittest.TestCase):
    def test_exhaustive_valid(self):
        for n in range(1, 71):
            leaves = make_leaves(n)
            tree = MerkleTree(leaves)
            new_root = ref_mth(leaves)
            for m in range(1, n + 1):
                old_root = ref_mth(leaves[:m])
                proof = tree.consistency_proof(m, n)
                self.assertTrue(verify_consistency(m, n, old_root, new_root, proof), (m, n))

    def test_exhaustive_rejection(self):
        for n in range(2, 41):
            leaves = make_leaves(n)
            tree = MerkleTree(leaves)
            new_root = tree.root()
            for m in range(1, n):
                old_root = ref_mth(leaves[:m])
                proof = tree.consistency_proof(m, n)
                self.assertFalse(verify_consistency(m, n, flip(old_root), new_root, proof), (m, n))
                self.assertFalse(verify_consistency(m, n, old_root, flip(new_root), proof), (m, n))
                for j in range(len(proof)):
                    bad = list(proof)
                    bad[j] = flip(bad[j], bit=(j * 3) % 8)
                    self.assertFalse(verify_consistency(m, n, old_root, new_root, bad), (m, n, j))
                if proof:
                    self.assertFalse(verify_consistency(m, n, old_root, new_root, proof[:-1]))
                    self.assertFalse(verify_consistency(m, n, old_root, new_root, proof[1:]))
                self.assertFalse(verify_consistency(m, n, old_root, new_root, proof + [new_root]))
                # claiming different sizes with the same proof must fail,
                # even when each claimed size is paired with its honest root
                extended = make_leaves(n + 1)
                if m + 1 < n:
                    self.assertFalse(
                        verify_consistency(m + 1, n, ref_mth(leaves[:m + 1]), new_root, proof), (m, n))
                self.assertFalse(
                    verify_consistency(m, n + 1, old_root, ref_mth(extended), proof), (m, n))

    def test_diverging_history_is_rejected(self):
        """A fork that shares only a prefix must not be 'consistent' with the original."""
        base = make_leaves(20)
        forked = base[:10] + [b"evil-" + x for x in base[10:]]
        t_good, t_fork = MerkleTree(base), MerkleTree(forked)
        # fork keeps first 10 leaves, so size-10 roots agree and the fork is consistent with them
        self.assertEqual(t_good.root(10), t_fork.root(10))
        self.assertTrue(verify_consistency(10, 20, t_good.root(10), t_fork.root(), t_fork.consistency_proof(10, 20)))
        # but the fork is NOT consistent with the original's size-15 root
        for m in range(11, 20):
            proof = t_fork.consistency_proof(m, 20)
            self.assertFalse(verify_consistency(m, 20, t_good.root(m), t_fork.root(), proof), m)

    def test_equal_sizes(self):
        tree = MerkleTree(make_leaves(9))
        r = tree.root()
        self.assertEqual(tree.consistency_proof(9, 9), [])
        self.assertTrue(verify_consistency(9, 9, r, r, []))
        self.assertFalse(verify_consistency(9, 9, r, flip(r), []))
        self.assertFalse(verify_consistency(9, 9, r, r, [r]))


class SecurityProperties(unittest.TestCase):
    def test_leaf_and_node_hashes_are_domain_separated(self):
        a, b = hash_leaf(b"a"), hash_leaf(b"b")
        node = hash_children(a, b)
        # Second-preimage attempt: present the concatenation as a single leaf.
        self.assertNotEqual(hash_leaf(b"\x01" + a + b), node)
        self.assertNotEqual(MerkleTree([b"\x01" + a + b]).root(), MerkleTree([b"a", b"b"]).root())

    def test_interior_hash_cannot_pose_as_leaf(self):
        leaves = make_leaves(4)
        tree = MerkleTree(leaves)
        left = hash_children(hash_leaf(leaves[0]), hash_leaf(leaves[1]))
        right = hash_children(hash_leaf(leaves[2]), hash_leaf(leaves[3]))
        # Attacker offers the interior node hash as "leaf data" for a 2-leaf tree.
        self.assertFalse(verify_inclusion(left, 0, 2, [right], tree.root()))
        self.assertFalse(verify_inclusion(left + right, 0, 1, [], tree.root()))

    def test_no_duplicate_padding_ambiguity(self):
        """CVE-2012-2459 shape: [a,b,c] and [a,b,c,c] must have different roots."""
        self.assertNotEqual(
            MerkleTree([b"a", b"b", b"c"]).root(),
            MerkleTree([b"a", b"b", b"c", b"c"]).root(),
        )

    def test_order_and_content_sensitivity(self):
        self.assertNotEqual(MerkleTree([b"a", b"b"]).root(), MerkleTree([b"b", b"a"]).root())
        self.assertNotEqual(MerkleTree([b"a"]).root(), MerkleTree([b"a", b""]).root())
        self.assertNotEqual(MerkleTree([]).root(), MerkleTree([b""]).root())


class InputValidation(unittest.TestCase):
    def test_generators_raise_on_caller_error(self):
        tree = MerkleTree(make_leaves(5))
        for bad in (-1, 5, 99, "0", 1.0, None, True):
            with self.assertRaises(IndexError):
                tree.inclusion_proof(bad)
        with self.assertRaises(ValueError):
            tree.inclusion_proof(0, 6)
        for old, new in ((0, 5), (6, 5), (3, 6), (-1, 5), ("2", 5), (True, 5)):
            with self.assertRaises(ValueError, msg=(old, new)):
                tree.consistency_proof(old, new)
        with self.assertRaises(ValueError):
            tree.root(6)
        with self.assertRaises(ValueError):
            tree.root(-1)

    def test_str_is_rejected_not_silently_encoded(self):
        with self.assertRaises(TypeError):
            MerkleTree().append("text")
        with self.assertRaises(TypeError):
            hash_leaf("text")

    def test_hash_children_requires_digests(self):
        with self.assertRaises(ValueError):
            hash_children(b"short", b"x" * 32)
        with self.assertRaises(ValueError):
            hash_children(b"x" * 32, b"x" * 33)

    def test_leaf_data_is_copied(self):
        buf = bytearray(b"mutable")
        tree = MerkleTree()
        tree.append(buf)
        before = tree.root()
        buf[0] ^= 0xFF
        self.assertEqual(tree.root(), before)

    def test_verifiers_never_raise_on_garbage(self):
        r = b"\x00" * 32
        junk = [None, "x", 1.5, b"", b"short", [b"short"], [1], object(), True, -1, 10**100]
        for a in junk:
            for b in junk:
                self.assertFalse(verify_inclusion(a, b, a, b, a))
                self.assertFalse(verify_inclusion(b"x", a, b, [r], r))
                self.assertFalse(verify_consistency(a, b, a, b, a))
                self.assertFalse(verify_consistency(1, 2, r, r, [b]))
        self.assertFalse(verify_inclusion(b"x", 0, 0, [], r))
        self.assertFalse(verify_inclusion(b"x", 1, 1, [], r))
        self.assertFalse(verify_consistency(0, 1, r, r, []))
        self.assertFalse(verify_consistency(2, 1, r, r, []))
        self.assertFalse(verify_consistency(1, 2, r, r, []))  # power-of-two old, empty proof


class RandomizedLarge(unittest.TestCase):
    def test_seeded_random_large_tree(self):
        rng = random.Random(0xC0FFEE)
        n = 5000
        leaves = [rng.randbytes(rng.randrange(0, 64)) + i.to_bytes(4, "big") for i in range(n)]
        tree = MerkleTree(leaves)
        self.assertEqual(tree.root(), ref_mth(leaves))
        for _ in range(300):
            size = rng.randrange(1, n + 1)
            m = rng.randrange(size)
            root = tree.root(size)
            self.assertTrue(verify_inclusion(leaves[m], m, size, tree.inclusion_proof(m, size), root))
            old = rng.randrange(1, size + 1)
            self.assertTrue(
                verify_consistency(old, size, tree.root(old), root, tree.consistency_proof(old, size))
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
