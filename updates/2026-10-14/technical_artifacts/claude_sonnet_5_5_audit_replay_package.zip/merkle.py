"""
merkle.py - append-only Merkle tree with inclusion and consistency proofs.

Implements the tree hash and proof algorithms of RFC 6962 (Certificate
Transparency) as restated in RFC 9162, using SHA-256. Standard library only.

Design properties
-----------------
* Domain separation: leaves hash as H(0x00 || data), interior nodes as
  H(0x01 || left || right). A leaf can never be confused with an interior
  node, which closes the classic second-preimage attack on naive Merkle trees.
  The public verifier takes raw leaf *data* and hashes it itself, so a caller
  cannot smuggle an interior-node hash in as a "leaf hash".
* Non-power-of-two sizes are handled by the RFC split rule (left subtree is
  the largest power of two strictly smaller than n); no duplicate-last-leaf
  padding, which is the source of CVE-2012-2459-style ambiguity.
* Append is amortised O(1); root, inclusion proof and consistency proof are
  O(log n). Historical roots and proofs for any prefix size are supported
  because the tree is append-only.
* Verifiers are total functions: any malformed input returns False and never
  raises. Generators raise on caller errors (bad index, bad size, wrong type).
* Verifiers are iterative and independent of the recursive generators, so the
  two cross-check each other in the test suite.
* Trust model: a proof authenticates a leaf (or a prefix) relative to a
  (size, root) pair. That pair must come from a trusted source such as a
  signed tree head. Proof shape alone does not authenticate the size: index 0
  has the same path shape at sizes 3 and 4, so a root for size 3 verifies if
  the caller claims size 4. This is inherent to the RFC algorithm; see
  SizeBinding in the tests.

Public API
----------
    hash_empty() -> bytes
    hash_leaf(data) -> bytes
    hash_children(left, right) -> bytes
    MerkleTree.append / root / inclusion_proof / consistency_proof
    verify_inclusion(leaf_data, index, tree_size, proof, root) -> bool
    verify_consistency(old_size, new_size, old_root, new_root, proof) -> bool
"""

from __future__ import annotations

import hashlib
import hmac
from typing import Iterable, List, Optional, Sequence

__all__ = [
    "HASH_LEN",
    "MerkleTree",
    "hash_children",
    "hash_empty",
    "hash_leaf",
    "verify_consistency",
    "verify_inclusion",
]

HASH_LEN = 32
_LEAF_PREFIX = b"\x00"
_NODE_PREFIX = b"\x01"


# --------------------------------------------------------------------------
# Hashing primitives
# --------------------------------------------------------------------------

def _sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def hash_empty() -> bytes:
    """Root of the empty tree: SHA-256 of the empty string."""
    return _sha256(b"")


def hash_leaf(data: bytes) -> bytes:
    """Leaf hash: SHA-256(0x00 || data)."""
    _require_bytes(data, "data")
    return _sha256(_LEAF_PREFIX + bytes(data))


def hash_children(left: bytes, right: bytes) -> bytes:
    """Interior hash: SHA-256(0x01 || left || right). Children must be 32 bytes."""
    if not (_is_hash(left) and _is_hash(right)):
        raise ValueError(f"children must be {HASH_LEN}-byte digests")
    return _sha256(_NODE_PREFIX + left + right)


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

def _require_bytes(value: object, name: str) -> None:
    if not isinstance(value, (bytes, bytearray, memoryview)):
        raise TypeError(f"{name} must be bytes-like, got {type(value).__name__}")


def _is_hash(value: object) -> bool:
    return isinstance(value, bytes) and len(value) == HASH_LEN


def _is_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _eq(a: bytes, b: bytes) -> bool:
    return hmac.compare_digest(a, b)


def _is_pow2(n: int) -> bool:
    return n > 0 and (n & (n - 1)) == 0


def _split(n: int) -> int:
    """Largest power of two strictly less than n. Requires n >= 2."""
    return 1 << ((n - 1).bit_length() - 1)


# --------------------------------------------------------------------------
# The tree
# --------------------------------------------------------------------------

class MerkleTree:
    """
    Append-only Merkle tree.

    Internally keeps, for each level k, the hashes of every *complete* subtree
    of 2**k leaves (level 0 = leaf hashes). Every subtree the RFC recursion
    ever asks for is either one of these or is built from them, so any range
    hash costs O(log n).
    """

    __slots__ = ("_levels",)

    def __init__(self, leaves: Iterable[bytes] = ()) -> None:
        self._levels: List[List[bytes]] = [[]]
        for leaf in leaves:
            self.append(leaf)

    def __len__(self) -> int:
        return len(self._levels[0])

    # -- mutation ----------------------------------------------------------

    def append(self, data: bytes) -> int:
        """Append a leaf; returns its index."""
        index = len(self)
        node = hash_leaf(data)
        level = 0
        self._levels[0].append(node)
        # Invariant: len(levels[k]) == n >> k. When a level reaches an even
        # count, its last two nodes complete a parent one level up.
        while len(self._levels[level]) % 2 == 0:
            nodes = self._levels[level]
            parent = hash_children(nodes[-2], nodes[-1])
            level += 1
            if level == len(self._levels):
                self._levels.append([])
            self._levels[level].append(parent)
        return index

    # -- queries -----------------------------------------------------------

    def root(self, size: Optional[int] = None) -> bytes:
        """Root hash of the first `size` leaves (default: all)."""
        n = self._resolve_size(size)
        return self._range_hash(0, n)

    def inclusion_proof(self, index: int, size: Optional[int] = None) -> List[bytes]:
        """Audit path proving leaf `index` is in the tree of the first `size` leaves."""
        n = self._resolve_size(size)
        if not _is_int(index) or not 0 <= index < n:
            raise IndexError(f"leaf index {index!r} out of range for tree size {n}")
        siblings: List[bytes] = []
        start, end = 0, n
        while end - start > 1:
            k = _split(end - start)
            if index < start + k:
                siblings.append(self._range_hash(start + k, end))
                end = start + k
            else:
                siblings.append(self._range_hash(start, start + k))
                start += k
        siblings.reverse()  # RFC order: deepest sibling first
        return siblings

    def consistency_proof(self, old_size: int, new_size: Optional[int] = None) -> List[bytes]:
        """
        Proof that the tree of the first `old_size` leaves is a prefix of the
        tree of the first `new_size` leaves. Requires 1 <= old_size <= new_size.
        """
        n = self._resolve_size(new_size)
        if not _is_int(old_size) or not 1 <= old_size <= n:
            raise ValueError(f"need 1 <= old_size <= new_size; got {old_size!r}, {n}")
        if old_size == n:
            return []
        siblings: List[bytes] = []
        start, end = 0, n
        on_left_edge = True  # RFC's flag "b": subtree is still the original old tree's prefix
        while old_size != end:
            k = _split(end - start)
            if old_size <= start + k:
                siblings.append(self._range_hash(start + k, end))
                end = start + k
            else:
                siblings.append(self._range_hash(start, start + k))
                start += k
                on_left_edge = False
        if not on_left_edge:
            siblings.append(self._range_hash(start, end))
        siblings.reverse()
        return siblings

    # -- internals ---------------------------------------------------------

    def _resolve_size(self, size: Optional[int]) -> int:
        if size is None:
            return len(self)
        if not _is_int(size) or not 0 <= size <= len(self):
            raise ValueError(f"size {size!r} out of range 0..{len(self)}")
        return size

    def _range_hash(self, start: int, end: int) -> bytes:
        """MTH(D[start:end]) per RFC 6962 section 2.1."""
        size = end - start
        if size == 0:
            return hash_empty()
        if _is_pow2(size):
            level = size.bit_length() - 1
            assert start & (size - 1) == 0, "subtree must be aligned"
            return self._levels[level][start >> level]
        k = _split(size)
        return hash_children(
            self._range_hash(start, start + k),
            self._range_hash(start + k, end),
        )


# --------------------------------------------------------------------------
# Verification (RFC 9162 sections 2.1.3.2 and 2.1.4.2)
# --------------------------------------------------------------------------

def _well_formed_proof(proof: object) -> bool:
    return isinstance(proof, (list, tuple)) and all(_is_hash(p) for p in proof)


def verify_inclusion(
    leaf_data: bytes,
    index: int,
    tree_size: int,
    proof: Sequence[bytes],
    root: bytes,
) -> bool:
    """True iff `leaf_data` sits at `index` in a tree of `tree_size` leaves with this root."""
    if not isinstance(leaf_data, (bytes, bytearray, memoryview)):
        return False
    if not (_is_int(index) and _is_int(tree_size)):
        return False
    if not (0 <= index < tree_size):
        return False
    if not (_well_formed_proof(proof) and _is_hash(root)):
        return False

    fn, sn = index, tree_size - 1
    r = hash_leaf(leaf_data)
    for p in proof:
        if sn == 0:
            return False  # proof longer than the path
        if fn & 1 or fn == sn:
            r = hash_children(p, r)
            if not fn & 1:
                while not fn & 1 and fn != 0:
                    fn >>= 1
                    sn >>= 1
        else:
            r = hash_children(r, p)
        fn >>= 1
        sn >>= 1
    return sn == 0 and _eq(r, root)


def verify_consistency(
    old_size: int,
    new_size: int,
    old_root: bytes,
    new_root: bytes,
    proof: Sequence[bytes],
) -> bool:
    """True iff the tree (old_size, old_root) is a prefix of the tree (new_size, new_root)."""
    if not (_is_int(old_size) and _is_int(new_size)):
        return False
    if not 1 <= old_size <= new_size:
        return False
    if not (_is_hash(old_root) and _is_hash(new_root) and _well_formed_proof(proof)):
        return False
    if old_size == new_size:
        return len(proof) == 0 and _eq(old_root, new_root)

    path = list(proof)
    if _is_pow2(old_size):
        path.insert(0, old_root)
    if not path:
        return False

    fn, sn = old_size - 1, new_size - 1
    while fn & 1:
        fn >>= 1
        sn >>= 1

    fr = sr = path[0]
    for c in path[1:]:
        if sn == 0:
            return False
        if fn & 1 or fn == sn:
            fr = hash_children(c, fr)
            sr = hash_children(c, sr)
            if not fn & 1:
                while not fn & 1 and fn != 0:
                    fn >>= 1
                    sn >>= 1
        else:
            sr = hash_children(sr, c)
        fn >>= 1
        sn >>= 1
    return sn == 0 and _eq(fr, old_root) and _eq(sr, new_root)
