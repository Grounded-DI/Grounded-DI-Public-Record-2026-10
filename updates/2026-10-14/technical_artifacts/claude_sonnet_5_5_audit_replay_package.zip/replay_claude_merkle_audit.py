#!/usr/bin/env python3
"""Replayable independent audit of supplied Merkle Python source.
Run: python -S replay_claude_merkle_audit.py
Inputs: sibling merkle.py; optional test_merkle.py, expected hashes in manifest.
No external dependencies or network required.
"""
from __future__ import annotations
import hashlib, importlib.util, json, os, pathlib, random, sys, time, concurrent.futures, threading
from functools import lru_cache

HERE = pathlib.Path(__file__).resolve().parent
SOURCE = HERE / "merkle.py"
assert SOURCE.exists(), "Place supplied merkle.py beside this harness."
sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location("original_merkle", SOURCE)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
start = time.perf_counter()
results = {
    "source_sha256": sha,
    "python": sys.version.split()[0],
    "source": "merkle.py",
    "reference_note": "Independent recursive reference: SHA-256 formulas and proof recursion",
}

leaves = [b"leaf-" + str(i).encode() for i in range(1025)]
@lru_cache(maxsize=None)
def mth(a, b):
    n = b-a
    if n == 0:
        return hashlib.sha256(b"").digest()
    if n == 1:
        return hashlib.sha256(b"\x00" + leaves[a]).digest()
    k = 1 << ((n-1).bit_length()-1)
    return hashlib.sha256(b"\x01" + mth(a,a+k) + mth(a+k,b)).digest()

def inclusion_ref(index, a, b):
    n = b-a
    if n == 1:
        return []
    k = 1 << ((n-1).bit_length()-1)
    if index < a+k:
        return inclusion_ref(index, a, a+k) + [mth(a+k,b)]
    return inclusion_ref(index, a+k,b) + [mth(a,a+k)]

def consistency_ref(old_size,a,b,on_left_edge=True):
    n=b-a
    if old_size == n:
        return [] if on_left_edge else [mth(a,b)]
    k=1 << ((n-1).bit_length()-1)
    if old_size <= k:
        return consistency_ref(old_size,a,a+k,on_left_edge) + [mth(a+k,b)]
    return consistency_ref(old_size-k,a+k,b,False) + [mth(a,a+k)]

count_incl=0
count_cons=0
for n in range(1,151):
    tree = m.MerkleTree(leaves[:n])
    assert tree.root() == mth(0,n), ("root",n)
    for index in range(n):
        p=tree.inclusion_proof(index)
        assert p==inclusion_ref(index,0,n), ("proof_inclusion",n,index)
        assert m.verify_inclusion(leaves[index], index, n, p, mth(0,n))
        count_incl+=1
    for old in range(1,n+1):
        p=tree.consistency_proof(old)
        assert p==consistency_ref(old,0,n), ("proof_consistency",old,n)
        assert m.verify_consistency(old,n,mth(0,old),mth(0,n),p)
        count_cons+=1
results["independent_exact_inclusion_proofs"]=count_incl
results["independent_exact_consistency_proofs"]=count_cons

tree_big = m.MerkleTree(leaves)
results["historical_roots_tested"]=1025
for n in range(1,1026):
    assert tree_big.root(n)==mth(0,n), ("historical_root",n)

rng=random.Random(0xACED)
tamper_ok=0
for _ in range(5000):
    n=rng.randrange(1,251)
    index=rng.randrange(n)
    proof=tree_big.inclusion_proof(index,n)
    root=tree_big.root(n)
    if rng.randrange(2)==0 or not proof:
        altered = b"flip-" + leaves[index]
        accepted=m.verify_inclusion(altered,index,n,proof,root)
    else:
        j=rng.randrange(len(proof))
        corrupted=list(proof)
        v=bytearray(corrupted[j]); v[rng.randrange(32)] ^= 1 << rng.randrange(8); corrupted[j]=bytes(v)
        accepted=m.verify_inclusion(leaves[index],index,n,corrupted,root)
    assert not accepted, ("tamper",n,index)
    tamper_ok+=1
results["mutated_proofs_or_leaves_rejected"]=tamper_ok

released=memoryview(b"bad")
released.release()
try:
    val=m.verify_inclusion(released,0,1,[],m.hash_leaf(b"bad"))
    results["released_memoryview_inclusion"]={"kind":"return","value":val}
except Exception as e:
    results["released_memoryview_inclusion"]={"kind":"exception","class":type(e).__name__,"message":str(e)}

class MalformedList(list):
    def __iter__(self):
        raise RuntimeError("malformed iteration")
try:
    val=m.verify_inclusion(b"x",0,1,MalformedList([]),m.hash_leaf(b"x"))
    results["malformed_list_inclusion"]={"kind":"return","value":val}
except Exception as e:
    results["malformed_list_inclusion"]={"kind":"exception","class":type(e).__name__,"message":str(e)}

# Detect duplicate indices under concurrent caller use.
# Threads start hashing 8MiB different payloads simultaneously.
concurrency=[]
for trial in range(12):
    tree=m.MerkleTree()
    barrier=threading.Barrier(3)
    data_a=bytes([65 + trial%25]) * (8*1024*1024)
    data_b=bytes([90 - trial%25]) * (8*1024*1024)
    observations=[None,None]
    def worker(i, data):
        barrier.wait()
        observations[i]=tree.append(data)
    ta=threading.Thread(target=worker,args=(0,data_a))
    tb=threading.Thread(target=worker,args=(1,data_b))
    ta.start();tb.start()
    barrier.wait()
    ta.join();tb.join()
    concurrency.append({"trial":trial+1, "indices":observations,"tree_length":len(tree),"duplicate":observations[0]==observations[1]})
results["concurrent_append_trials"]=12
results["duplicate_index_trials"]=sum(1 for c in concurrency if c["duplicate"])
results["concurrent_append_observations"]=concurrency
results["elapsed_seconds"]=round(time.perf_counter()-start,3)
print(json.dumps(results,indent=2,sort_keys=True))
